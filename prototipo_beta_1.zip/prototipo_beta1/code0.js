gdjs.level0Code = {};
gdjs.level0Code.GDplataformaObjects1= [];
gdjs.level0Code.GDplataformaObjects2= [];
gdjs.level0Code.GDplataformaObjects3= [];
gdjs.level0Code.GDheroiObjects1= [];
gdjs.level0Code.GDheroiObjects2= [];
gdjs.level0Code.GDheroiObjects3= [];
gdjs.level0Code.GDtiledpiece2Objects1= [];
gdjs.level0Code.GDtiledpiece2Objects2= [];
gdjs.level0Code.GDtiledpiece2Objects3= [];
gdjs.level0Code.GDtiledpiece1Objects1= [];
gdjs.level0Code.GDtiledpiece1Objects2= [];
gdjs.level0Code.GDtiledpiece1Objects3= [];
gdjs.level0Code.GDmais_95zoomObjects1= [];
gdjs.level0Code.GDmais_95zoomObjects2= [];
gdjs.level0Code.GDmais_95zoomObjects3= [];
gdjs.level0Code.GDmenos_95zoomObjects1= [];
gdjs.level0Code.GDmenos_95zoomObjects2= [];
gdjs.level0Code.GDmenos_95zoomObjects3= [];
gdjs.level0Code.GDcamera1Objects1= [];
gdjs.level0Code.GDcamera1Objects2= [];
gdjs.level0Code.GDcamera1Objects3= [];
gdjs.level0Code.GDfundo_95backgroundObjects1= [];
gdjs.level0Code.GDfundo_95backgroundObjects2= [];
gdjs.level0Code.GDfundo_95backgroundObjects3= [];
gdjs.level0Code.GDinventario_95gridObjects1= [];
gdjs.level0Code.GDinventario_95gridObjects2= [];
gdjs.level0Code.GDinventario_95gridObjects3= [];
gdjs.level0Code.GDTIMERObjects1= [];
gdjs.level0Code.GDTIMERObjects2= [];
gdjs.level0Code.GDTIMERObjects3= [];
gdjs.level0Code.GDbox1Objects1= [];
gdjs.level0Code.GDbox1Objects2= [];
gdjs.level0Code.GDbox1Objects3= [];
gdjs.level0Code.GDico_95box1Objects1= [];
gdjs.level0Code.GDico_95box1Objects2= [];
gdjs.level0Code.GDico_95box1Objects3= [];
gdjs.level0Code.GDqtd_95box1Objects1= [];
gdjs.level0Code.GDqtd_95box1Objects2= [];
gdjs.level0Code.GDqtd_95box1Objects3= [];
gdjs.level0Code.GDbolaObjects1= [];
gdjs.level0Code.GDbolaObjects2= [];
gdjs.level0Code.GDbolaObjects3= [];
gdjs.level0Code.GDico_95bolaObjects1= [];
gdjs.level0Code.GDico_95bolaObjects2= [];
gdjs.level0Code.GDico_95bolaObjects3= [];
gdjs.level0Code.GDqtd_95bolaObjects1= [];
gdjs.level0Code.GDqtd_95bolaObjects2= [];
gdjs.level0Code.GDqtd_95bolaObjects3= [];
gdjs.level0Code.GDmolaObjects1= [];
gdjs.level0Code.GDmolaObjects2= [];
gdjs.level0Code.GDmolaObjects3= [];
gdjs.level0Code.GDico_95molaObjects1= [];
gdjs.level0Code.GDico_95molaObjects2= [];
gdjs.level0Code.GDico_95molaObjects3= [];
gdjs.level0Code.GDqtd_95molaObjects1= [];
gdjs.level0Code.GDqtd_95molaObjects2= [];
gdjs.level0Code.GDqtd_95molaObjects3= [];
gdjs.level0Code.GDoutbox_95itemObjects1= [];
gdjs.level0Code.GDoutbox_95itemObjects2= [];
gdjs.level0Code.GDoutbox_95itemObjects3= [];
gdjs.level0Code.GDcenter_95screenObjects1= [];
gdjs.level0Code.GDcenter_95screenObjects2= [];
gdjs.level0Code.GDcenter_95screenObjects3= [];
gdjs.level0Code.GDsprite_95aguaObjects1= [];
gdjs.level0Code.GDsprite_95aguaObjects2= [];
gdjs.level0Code.GDsprite_95aguaObjects3= [];
gdjs.level0Code.GDplataforma1Objects1= [];
gdjs.level0Code.GDplataforma1Objects2= [];
gdjs.level0Code.GDplataforma1Objects3= [];
gdjs.level0Code.GDico_95plataforma1Objects1= [];
gdjs.level0Code.GDico_95plataforma1Objects2= [];
gdjs.level0Code.GDico_95plataforma1Objects3= [];
gdjs.level0Code.GDqtd_95plataforma1Objects1= [];
gdjs.level0Code.GDqtd_95plataforma1Objects2= [];
gdjs.level0Code.GDqtd_95plataforma1Objects3= [];
gdjs.level0Code.GDclique_95aquiObjects1= [];
gdjs.level0Code.GDclique_95aquiObjects2= [];
gdjs.level0Code.GDclique_95aquiObjects3= [];

gdjs.level0Code.conditionTrue_0 = {val:false};
gdjs.level0Code.condition0IsTrue_0 = {val:false};
gdjs.level0Code.condition1IsTrue_0 = {val:false};
gdjs.level0Code.condition2IsTrue_0 = {val:false};


gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDcenter_9595screenObjects1Objects = Hashtable.newFrom({"center_screen": gdjs.level0Code.GDcenter_95screenObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDheroiObjects1Objects = Hashtable.newFrom({"heroi": gdjs.level0Code.GDheroiObjects1});gdjs.level0Code.eventsList0x87a694 = function(runtimeScene) {

{

gdjs.level0Code.GDcenter_95screenObjects2.createFrom(gdjs.level0Code.GDcenter_95screenObjects1);

gdjs.level0Code.GDheroiObjects2.createFrom(gdjs.level0Code.GDheroiObjects1);


gdjs.level0Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level0Code.GDcenter_95screenObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDcenter_95screenObjects2[i].getX() < (( gdjs.level0Code.GDheroiObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDheroiObjects2[0].getPointX("")) ) {
        gdjs.level0Code.condition0IsTrue_0.val = true;
        gdjs.level0Code.GDcenter_95screenObjects2[k] = gdjs.level0Code.GDcenter_95screenObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDcenter_95screenObjects2.length = k;}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDcenter_95screenObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDcenter_95screenObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDcenter_95screenObjects2[i].setX(gdjs.level0Code.GDcenter_95screenObjects2[i].getX() + (5));
}
}}

}


{

gdjs.level0Code.GDcenter_95screenObjects2.createFrom(gdjs.level0Code.GDcenter_95screenObjects1);

gdjs.level0Code.GDheroiObjects2.createFrom(gdjs.level0Code.GDheroiObjects1);


gdjs.level0Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level0Code.GDcenter_95screenObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDcenter_95screenObjects2[i].getX() > (( gdjs.level0Code.GDheroiObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDheroiObjects2[0].getPointX("")) ) {
        gdjs.level0Code.condition0IsTrue_0.val = true;
        gdjs.level0Code.GDcenter_95screenObjects2[k] = gdjs.level0Code.GDcenter_95screenObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDcenter_95screenObjects2.length = k;}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDcenter_95screenObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDcenter_95screenObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDcenter_95screenObjects2[i].setX(gdjs.level0Code.GDcenter_95screenObjects2[i].getX() - (5));
}
}}

}


{

gdjs.level0Code.GDcenter_95screenObjects2.createFrom(gdjs.level0Code.GDcenter_95screenObjects1);

gdjs.level0Code.GDheroiObjects2.createFrom(gdjs.level0Code.GDheroiObjects1);


gdjs.level0Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level0Code.GDcenter_95screenObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDcenter_95screenObjects2[i].getY() < (( gdjs.level0Code.GDheroiObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDheroiObjects2[0].getPointY("")) ) {
        gdjs.level0Code.condition0IsTrue_0.val = true;
        gdjs.level0Code.GDcenter_95screenObjects2[k] = gdjs.level0Code.GDcenter_95screenObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDcenter_95screenObjects2.length = k;}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDcenter_95screenObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDcenter_95screenObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDcenter_95screenObjects2[i].setY(gdjs.level0Code.GDcenter_95screenObjects2[i].getY() + (5));
}
}}

}


{

/* Reuse gdjs.level0Code.GDcenter_95screenObjects1 */
/* Reuse gdjs.level0Code.GDheroiObjects1 */

gdjs.level0Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level0Code.GDcenter_95screenObjects1.length;i<l;++i) {
    if ( gdjs.level0Code.GDcenter_95screenObjects1[i].getY() < (( gdjs.level0Code.GDheroiObjects1.length === 0 ) ? 0 :gdjs.level0Code.GDheroiObjects1[0].getPointY("")) ) {
        gdjs.level0Code.condition0IsTrue_0.val = true;
        gdjs.level0Code.GDcenter_95screenObjects1[k] = gdjs.level0Code.GDcenter_95screenObjects1[i];
        ++k;
    }
}
gdjs.level0Code.GDcenter_95screenObjects1.length = k;}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDcenter_95screenObjects1 */
{for(var i = 0, len = gdjs.level0Code.GDcenter_95screenObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDcenter_95screenObjects1[i].setX(gdjs.level0Code.GDcenter_95screenObjects1[i].getX() - (5));
}
}}

}


}; //End of gdjs.level0Code.eventsList0x87a694
gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmenos_9595zoomObjects1Objects = Hashtable.newFrom({"menos_zoom": gdjs.level0Code.GDmenos_95zoomObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmais_9595zoomObjects1Objects = Hashtable.newFrom({"mais_zoom": gdjs.level0Code.GDmais_95zoomObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDheroiObjects1Objects = Hashtable.newFrom({"heroi": gdjs.level0Code.GDheroiObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDtiledpiece1Objects1ObjectsGDgdjs_46level0Code_46GDbox1Objects1ObjectsGDgdjs_46level0Code_46GDmolaObjects1ObjectsGDgdjs_46level0Code_46GDplataforma1Objects1Objects = Hashtable.newFrom({"tiledpiece1": gdjs.level0Code.GDtiledpiece1Objects1, "box1": gdjs.level0Code.GDbox1Objects1, "mola": gdjs.level0Code.GDmolaObjects1, "plataforma1": gdjs.level0Code.GDplataforma1Objects1});gdjs.level0Code.eventsList0x858414 = function(runtimeScene) {

{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDheroiObjects1 */
{for(var i = 0, len = gdjs.level0Code.GDheroiObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDheroiObjects1[i].getBehavior("Physics2").applyForce(0, -(120), 0, 0);
}
}}

}


}; //End of gdjs.level0Code.eventsList0x858414
gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDheroiObjects1Objects = Hashtable.newFrom({"heroi": gdjs.level0Code.GDheroiObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDbolaObjects1Objects = Hashtable.newFrom({"bola": gdjs.level0Code.GDbolaObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmolaObjects1Objects = Hashtable.newFrom({"mola": gdjs.level0Code.GDmolaObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDtiledpiece1Objects1Objects = Hashtable.newFrom({"tiledpiece1": gdjs.level0Code.GDtiledpiece1Objects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDclique_9595aquiObjects1Objects = Hashtable.newFrom({"clique_aqui": gdjs.level0Code.GDclique_95aquiObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDoutbox_9595itemObjects1Objects = Hashtable.newFrom({"outbox_item": gdjs.level0Code.GDoutbox_95itemObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDclique_9595aquiObjects1Objects = Hashtable.newFrom({"clique_aqui": gdjs.level0Code.GDclique_95aquiObjects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595plataforma1Objects2Objects = Hashtable.newFrom({"ico_plataforma1": gdjs.level0Code.GDico_95plataforma1Objects2});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDplataforma1Objects2Objects = Hashtable.newFrom({"plataforma1": gdjs.level0Code.GDplataforma1Objects2});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595molaObjects2Objects = Hashtable.newFrom({"ico_mola": gdjs.level0Code.GDico_95molaObjects2});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmolaObjects2Objects = Hashtable.newFrom({"mola": gdjs.level0Code.GDmolaObjects2});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595bolaObjects2Objects = Hashtable.newFrom({"ico_bola": gdjs.level0Code.GDico_95bolaObjects2});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDbolaObjects2Objects = Hashtable.newFrom({"bola": gdjs.level0Code.GDbolaObjects2});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595box1Objects1Objects = Hashtable.newFrom({"ico_box1": gdjs.level0Code.GDico_95box1Objects1});gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDbox1Objects1Objects = Hashtable.newFrom({"box1": gdjs.level0Code.GDbox1Objects1});gdjs.level0Code.eventsList0x8b17ac = function(runtimeScene) {

{

gdjs.level0Code.GDico_95plataforma1Objects2.createFrom(runtimeScene.getObjects("ico_plataforma1"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595plataforma1Objects2Objects, runtimeScene, true, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDclique_95aquiObjects2.createFrom(gdjs.level0Code.GDclique_95aquiObjects1);

gdjs.level0Code.GDoutbox_95itemObjects2.createFrom(gdjs.level0Code.GDoutbox_95itemObjects1);

gdjs.level0Code.GDplataforma1Objects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDplataforma1Objects2Objects, "plataforma1", (( gdjs.level0Code.GDoutbox_95itemObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects2[0].getPointX("")), (( gdjs.level0Code.GDoutbox_95itemObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects2[0].getPointY("")), "GAME");
}{for(var i = 0, len = gdjs.level0Code.GDclique_95aquiObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDclique_95aquiObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDoutbox_95itemObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDoutbox_95itemObjects2[i].hide();
}
}}

}


{

gdjs.level0Code.GDico_95molaObjects2.createFrom(runtimeScene.getObjects("ico_mola"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595molaObjects2Objects, runtimeScene, true, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDclique_95aquiObjects2.createFrom(gdjs.level0Code.GDclique_95aquiObjects1);

gdjs.level0Code.GDoutbox_95itemObjects2.createFrom(gdjs.level0Code.GDoutbox_95itemObjects1);

gdjs.level0Code.GDmolaObjects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmolaObjects2Objects, "mola", (( gdjs.level0Code.GDoutbox_95itemObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects2[0].getPointX("")), (( gdjs.level0Code.GDoutbox_95itemObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects2[0].getPointY("")), "GAME");
}{for(var i = 0, len = gdjs.level0Code.GDclique_95aquiObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDclique_95aquiObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDoutbox_95itemObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDoutbox_95itemObjects2[i].hide();
}
}}

}


{

gdjs.level0Code.GDico_95bolaObjects2.createFrom(runtimeScene.getObjects("ico_bola"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595bolaObjects2Objects, runtimeScene, true, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDclique_95aquiObjects2.createFrom(gdjs.level0Code.GDclique_95aquiObjects1);

gdjs.level0Code.GDoutbox_95itemObjects2.createFrom(gdjs.level0Code.GDoutbox_95itemObjects1);

gdjs.level0Code.GDbolaObjects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDbolaObjects2Objects, "bola", (( gdjs.level0Code.GDoutbox_95itemObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects2[0].getPointX("")), (( gdjs.level0Code.GDoutbox_95itemObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects2[0].getPointY("")), "GAME");
}{for(var i = 0, len = gdjs.level0Code.GDclique_95aquiObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDclique_95aquiObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDoutbox_95itemObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDoutbox_95itemObjects2[i].hide();
}
}}

}


{

gdjs.level0Code.GDico_95box1Objects1.createFrom(runtimeScene.getObjects("ico_box1"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDico_9595box1Objects1Objects, runtimeScene, true, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDclique_95aquiObjects1 */
/* Reuse gdjs.level0Code.GDoutbox_95itemObjects1 */
gdjs.level0Code.GDbox1Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDbox1Objects1Objects, "box1", (( gdjs.level0Code.GDoutbox_95itemObjects1.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects1[0].getPointX("")), (( gdjs.level0Code.GDoutbox_95itemObjects1.length === 0 ) ? 0 :gdjs.level0Code.GDoutbox_95itemObjects1[0].getPointY("")), "GAME");
}{for(var i = 0, len = gdjs.level0Code.GDclique_95aquiObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDclique_95aquiObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDoutbox_95itemObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDoutbox_95itemObjects1[i].hide();
}
}}

}


}; //End of gdjs.level0Code.eventsList0x8b17ac
gdjs.level0Code.eventsList0xb5aa0 = function(runtimeScene) {

{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDcenter_95screenObjects1.createFrom(runtimeScene.getObjects("center_screen"));
gdjs.level0Code.GDsprite_95aguaObjects1.createFrom(runtimeScene.getObjects("sprite_agua"));
{runtimeScene.getVariables().getFromIndex(0).setNumber(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "chance_time");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(99);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "mili_cicle");
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setY(1090);
}
}{for(var i = 0, len = gdjs.level0Code.GDcenter_95screenObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDcenter_95screenObjects1[i].hide();
}
}}

}


{

gdjs.level0Code.GDcenter_95screenObjects1.createFrom(runtimeScene.getObjects("center_screen"));
gdjs.level0Code.GDheroiObjects1.createFrom(runtimeScene.getObjects("heroi"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDcenter_9595screenObjects1Objects, gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDheroiObjects1Objects, 50, true);
}if (gdjs.level0Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.level0Code.eventsList0x87a694(runtimeScene);} //End of subevents
}

}


{


{
gdjs.level0Code.GDTIMERObjects1.createFrom(runtimeScene.getObjects("TIMER"));
gdjs.level0Code.GDcenter_95screenObjects1.createFrom(runtimeScene.getObjects("center_screen"));
gdjs.level0Code.GDfundo_95backgroundObjects1.createFrom(runtimeScene.getObjects("fundo_background"));
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.level0Code.GDcenter_95screenObjects1.length !== 0 ? gdjs.level0Code.GDcenter_95screenObjects1[0] : null), true, "GAME", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)), "GAME", 0);
}{for(var i = 0, len = gdjs.level0Code.GDfundo_95backgroundObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDfundo_95backgroundObjects1[i].setX(gdjs.evtTools.camera.getCameraX(runtimeScene, "GAME", 0) * -(0.3));
}
}{for(var i = 0, len = gdjs.level0Code.GDTIMERObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDTIMERObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}}

}


{

gdjs.level0Code.GDmenos_95zoomObjects1.createFrom(runtimeScene.getObjects("menos_zoom"));

gdjs.level0Code.condition0IsTrue_0.val = false;
gdjs.level0Code.condition1IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmenos_9595zoomObjects1Objects, runtimeScene, true, false);
}if ( gdjs.level0Code.condition0IsTrue_0.val ) {
{
gdjs.level0Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.level0Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).sub(0.1);
}}

}


{

gdjs.level0Code.GDmais_95zoomObjects1.createFrom(runtimeScene.getObjects("mais_zoom"));

gdjs.level0Code.condition0IsTrue_0.val = false;
gdjs.level0Code.condition1IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmais_9595zoomObjects1Objects, runtimeScene, true, false);
}if ( gdjs.level0Code.condition0IsTrue_0.val ) {
{
gdjs.level0Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.level0Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).add(0.1);
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
gdjs.level0Code.condition1IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "chance_time");
}if ( gdjs.level0Code.condition0IsTrue_0.val ) {
{
gdjs.level0Code.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) > 0;
}}
if (gdjs.level0Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "chance_time");
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "mili_cicle");
}if (gdjs.level0Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "mili_cicle");
}{runtimeScene.getVariables().getFromIndex(2).add(1);
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) <= 10;
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDsprite_95aguaObjects1.createFrom(runtimeScene.getObjects("sprite_agua"));
{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setHeight(gdjs.level0Code.GDsprite_95aguaObjects1[i].getHeight() + (0.3));
}
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setY(gdjs.level0Code.GDsprite_95aguaObjects1[i].getY() - (0.3));
}
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setOpacity(gdjs.level0Code.GDsprite_95aguaObjects1[i].getOpacity() - (1));
}
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 10;
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDsprite_95aguaObjects1.createFrom(runtimeScene.getObjects("sprite_agua"));
{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setHeight(gdjs.level0Code.GDsprite_95aguaObjects1[i].getHeight() - (0.3));
}
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setY(gdjs.level0Code.GDsprite_95aguaObjects1[i].getY() + (0.3));
}
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setOpacity(gdjs.level0Code.GDsprite_95aguaObjects1[i].getOpacity() + (1));
}
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 20;
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDsprite_95aguaObjects1.createFrom(runtimeScene.getObjects("sprite_agua"));
{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setY(1090);
}
}{for(var i = 0, len = gdjs.level0Code.GDsprite_95aguaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDsprite_95aguaObjects1[i].setOpacity(200);
}
}}

}


{

gdjs.level0Code.GDbox1Objects1.createFrom(runtimeScene.getObjects("box1"));
gdjs.level0Code.GDheroiObjects1.createFrom(runtimeScene.getObjects("heroi"));
gdjs.level0Code.GDmolaObjects1.createFrom(runtimeScene.getObjects("mola"));
gdjs.level0Code.GDplataforma1Objects1.createFrom(runtimeScene.getObjects("plataforma1"));
gdjs.level0Code.GDtiledpiece1Objects1.createFrom(runtimeScene.getObjects("tiledpiece1"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDheroiObjects1Objects, "Physics2", gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDtiledpiece1Objects1ObjectsGDgdjs_46level0Code_46GDbox1Objects1ObjectsGDgdjs_46level0Code_46GDmolaObjects1ObjectsGDgdjs_46level0Code_46GDplataforma1Objects1Objects, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.level0Code.eventsList0x858414(runtimeScene);} //End of subevents
}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDheroiObjects1.createFrom(runtimeScene.getObjects("heroi"));
{for(var i = 0, len = gdjs.level0Code.GDheroiObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDheroiObjects1[i].getBehavior("Physics2").applyImpulse(-(0.05), 0, 0, 0);
}
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDheroiObjects1.createFrom(runtimeScene.getObjects("heroi"));
{for(var i = 0, len = gdjs.level0Code.GDheroiObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDheroiObjects1[i].getBehavior("Physics2").applyImpulse(-(0.05), 0, 0, 0);
}
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDheroiObjects1.createFrom(runtimeScene.getObjects("heroi"));
{for(var i = 0, len = gdjs.level0Code.GDheroiObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDheroiObjects1[i].getBehavior("Physics2").applyImpulse(0.05, 0, 0, 0);
}
}}

}


{


gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.level0Code.condition0IsTrue_0.val) {
gdjs.level0Code.GDheroiObjects1.createFrom(runtimeScene.getObjects("heroi"));
{for(var i = 0, len = gdjs.level0Code.GDheroiObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDheroiObjects1[i].getBehavior("Physics2").applyImpulse(0.05, 0, 0, 0);
}
}}

}


{

gdjs.level0Code.GDbolaObjects1.createFrom(runtimeScene.getObjects("bola"));
gdjs.level0Code.GDheroiObjects1.createFrom(runtimeScene.getObjects("heroi"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDheroiObjects1Objects, "Physics2", gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDbolaObjects1Objects, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDbolaObjects1 */
{for(var i = 0, len = gdjs.level0Code.GDbolaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDbolaObjects1[i].getBehavior("Physics2").applyForceTowardPosition(10, 0, 0, 0, 0);
}
}}

}


{

gdjs.level0Code.GDmolaObjects1.createFrom(runtimeScene.getObjects("mola"));
gdjs.level0Code.GDtiledpiece1Objects1.createFrom(runtimeScene.getObjects("tiledpiece1"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDmolaObjects1Objects, "Physics2", gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDtiledpiece1Objects1Objects, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDmolaObjects1 */
{for(var i = 0, len = gdjs.level0Code.GDmolaObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDmolaObjects1[i].getBehavior("Physics2").setStatic();
}
}}

}


{

gdjs.level0Code.GDclique_95aquiObjects1.createFrom(runtimeScene.getObjects("clique_aqui"));

gdjs.level0Code.condition0IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDclique_9595aquiObjects1Objects, runtimeScene, true, false);
}if (gdjs.level0Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level0Code.GDclique_95aquiObjects1 */
gdjs.level0Code.GDoutbox_95itemObjects1.createFrom(runtimeScene.getObjects("outbox_item"));
{for(var i = 0, len = gdjs.level0Code.GDoutbox_95itemObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDoutbox_95itemObjects1[i].setPosition((( gdjs.level0Code.GDclique_95aquiObjects1.length === 0 ) ? 0 :gdjs.level0Code.GDclique_95aquiObjects1[0].getPointX("")),(( gdjs.level0Code.GDclique_95aquiObjects1.length === 0 ) ? 0 :gdjs.level0Code.GDclique_95aquiObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.level0Code.GDoutbox_95itemObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDoutbox_95itemObjects1[i].setZOrder(5000);
}
}{for(var i = 0, len = gdjs.level0Code.GDoutbox_95itemObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDoutbox_95itemObjects1[i].hide(false);
}
}}

}


{

gdjs.level0Code.GDclique_95aquiObjects1.createFrom(runtimeScene.getObjects("clique_aqui"));
gdjs.level0Code.GDoutbox_95itemObjects1.createFrom(runtimeScene.getObjects("outbox_item"));

gdjs.level0Code.condition0IsTrue_0.val = false;
gdjs.level0Code.condition1IsTrue_0.val = false;
{
gdjs.level0Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.level0Code.condition0IsTrue_0.val ) {
{
gdjs.level0Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDoutbox_9595itemObjects1Objects, gdjs.level0Code.mapOfGDgdjs_46level0Code_46GDclique_9595aquiObjects1Objects, false, runtimeScene, false);
}}
if (gdjs.level0Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.level0Code.eventsList0x8b17ac(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.level0Code.eventsList0xb5aa0


gdjs.level0Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level0Code.GDplataformaObjects1.length = 0;
gdjs.level0Code.GDplataformaObjects2.length = 0;
gdjs.level0Code.GDplataformaObjects3.length = 0;
gdjs.level0Code.GDheroiObjects1.length = 0;
gdjs.level0Code.GDheroiObjects2.length = 0;
gdjs.level0Code.GDheroiObjects3.length = 0;
gdjs.level0Code.GDtiledpiece2Objects1.length = 0;
gdjs.level0Code.GDtiledpiece2Objects2.length = 0;
gdjs.level0Code.GDtiledpiece2Objects3.length = 0;
gdjs.level0Code.GDtiledpiece1Objects1.length = 0;
gdjs.level0Code.GDtiledpiece1Objects2.length = 0;
gdjs.level0Code.GDtiledpiece1Objects3.length = 0;
gdjs.level0Code.GDmais_95zoomObjects1.length = 0;
gdjs.level0Code.GDmais_95zoomObjects2.length = 0;
gdjs.level0Code.GDmais_95zoomObjects3.length = 0;
gdjs.level0Code.GDmenos_95zoomObjects1.length = 0;
gdjs.level0Code.GDmenos_95zoomObjects2.length = 0;
gdjs.level0Code.GDmenos_95zoomObjects3.length = 0;
gdjs.level0Code.GDcamera1Objects1.length = 0;
gdjs.level0Code.GDcamera1Objects2.length = 0;
gdjs.level0Code.GDcamera1Objects3.length = 0;
gdjs.level0Code.GDfundo_95backgroundObjects1.length = 0;
gdjs.level0Code.GDfundo_95backgroundObjects2.length = 0;
gdjs.level0Code.GDfundo_95backgroundObjects3.length = 0;
gdjs.level0Code.GDinventario_95gridObjects1.length = 0;
gdjs.level0Code.GDinventario_95gridObjects2.length = 0;
gdjs.level0Code.GDinventario_95gridObjects3.length = 0;
gdjs.level0Code.GDTIMERObjects1.length = 0;
gdjs.level0Code.GDTIMERObjects2.length = 0;
gdjs.level0Code.GDTIMERObjects3.length = 0;
gdjs.level0Code.GDbox1Objects1.length = 0;
gdjs.level0Code.GDbox1Objects2.length = 0;
gdjs.level0Code.GDbox1Objects3.length = 0;
gdjs.level0Code.GDico_95box1Objects1.length = 0;
gdjs.level0Code.GDico_95box1Objects2.length = 0;
gdjs.level0Code.GDico_95box1Objects3.length = 0;
gdjs.level0Code.GDqtd_95box1Objects1.length = 0;
gdjs.level0Code.GDqtd_95box1Objects2.length = 0;
gdjs.level0Code.GDqtd_95box1Objects3.length = 0;
gdjs.level0Code.GDbolaObjects1.length = 0;
gdjs.level0Code.GDbolaObjects2.length = 0;
gdjs.level0Code.GDbolaObjects3.length = 0;
gdjs.level0Code.GDico_95bolaObjects1.length = 0;
gdjs.level0Code.GDico_95bolaObjects2.length = 0;
gdjs.level0Code.GDico_95bolaObjects3.length = 0;
gdjs.level0Code.GDqtd_95bolaObjects1.length = 0;
gdjs.level0Code.GDqtd_95bolaObjects2.length = 0;
gdjs.level0Code.GDqtd_95bolaObjects3.length = 0;
gdjs.level0Code.GDmolaObjects1.length = 0;
gdjs.level0Code.GDmolaObjects2.length = 0;
gdjs.level0Code.GDmolaObjects3.length = 0;
gdjs.level0Code.GDico_95molaObjects1.length = 0;
gdjs.level0Code.GDico_95molaObjects2.length = 0;
gdjs.level0Code.GDico_95molaObjects3.length = 0;
gdjs.level0Code.GDqtd_95molaObjects1.length = 0;
gdjs.level0Code.GDqtd_95molaObjects2.length = 0;
gdjs.level0Code.GDqtd_95molaObjects3.length = 0;
gdjs.level0Code.GDoutbox_95itemObjects1.length = 0;
gdjs.level0Code.GDoutbox_95itemObjects2.length = 0;
gdjs.level0Code.GDoutbox_95itemObjects3.length = 0;
gdjs.level0Code.GDcenter_95screenObjects1.length = 0;
gdjs.level0Code.GDcenter_95screenObjects2.length = 0;
gdjs.level0Code.GDcenter_95screenObjects3.length = 0;
gdjs.level0Code.GDsprite_95aguaObjects1.length = 0;
gdjs.level0Code.GDsprite_95aguaObjects2.length = 0;
gdjs.level0Code.GDsprite_95aguaObjects3.length = 0;
gdjs.level0Code.GDplataforma1Objects1.length = 0;
gdjs.level0Code.GDplataforma1Objects2.length = 0;
gdjs.level0Code.GDplataforma1Objects3.length = 0;
gdjs.level0Code.GDico_95plataforma1Objects1.length = 0;
gdjs.level0Code.GDico_95plataforma1Objects2.length = 0;
gdjs.level0Code.GDico_95plataforma1Objects3.length = 0;
gdjs.level0Code.GDqtd_95plataforma1Objects1.length = 0;
gdjs.level0Code.GDqtd_95plataforma1Objects2.length = 0;
gdjs.level0Code.GDqtd_95plataforma1Objects3.length = 0;
gdjs.level0Code.GDclique_95aquiObjects1.length = 0;
gdjs.level0Code.GDclique_95aquiObjects2.length = 0;
gdjs.level0Code.GDclique_95aquiObjects3.length = 0;

gdjs.level0Code.eventsList0xb5aa0(runtimeScene);
return;

}
gdjs['level0Code'] = gdjs.level0Code;
